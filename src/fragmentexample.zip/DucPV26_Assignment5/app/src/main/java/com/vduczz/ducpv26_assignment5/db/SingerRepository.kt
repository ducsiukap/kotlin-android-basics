package com.vduczz.ducpv26_assignment5.db

import com.vduczz.ducpv26_assignment5.models.SingerModel

object SingerRepository {
    fun findById(id: Int): SingerModel? {
        return Repository.findById<Singer>(id)?.toModel()
    }

    fun findAll(): List<SingerModel> {
        val songsBySinger = Repository.findAll<SongOfSinger>().groupBy { it.singerId }

        return Repository.findAll<Singer>().map { singer ->
            singer.toModel(
                songCount = songsBySinger
                    .getOrDefault(singer.id, emptyList())
                    .size
            )
        }
    }

    fun findAll(predicate: (SingerModel) -> Boolean): List<SingerModel> {
        val singers = this.findAll()
        return singers.filter(predicate)
    }

    fun findAllByIds(ids: List<Int>): List<SingerModel> {
        return this.findAll { it.id in ids }
    }
}


