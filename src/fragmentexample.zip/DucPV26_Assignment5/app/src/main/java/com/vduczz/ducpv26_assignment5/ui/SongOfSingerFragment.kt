package com.vduczz.ducpv26_assignment5.ui

import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.vduczz.ducpv26_assignment5.R
import com.vduczz.ducpv26_assignment5.adapter.SongAdapter
import com.vduczz.ducpv26_assignment5.databinding.SongFragmentBinding
import com.vduczz.ducpv26_assignment5.db.SingerRepository
import com.vduczz.ducpv26_assignment5.db.SongRepository
import com.vduczz.ducpv26_assignment5.models.SingerModel
import com.vduczz.ducpv26_assignment5.models.SongModel

class SongOfSingerFragment : Fragment() {
    companion object {
        private val LOG_TAG = SongOfSingerFragment::class.java.simpleName
        private const val APP_TITLE = "List songs"
        private const val ARG_SINGER_ID = "arg_singer_id"
        fun newInstance(singerId: Int) = SongOfSingerFragment()
            .apply {
                arguments = Bundle().apply {
                    putInt(ARG_SINGER_ID, singerId)
                }
            }
    }

    private var _binding: SongFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = SongFragmentBinding.inflate(
            inflater,
            container,
            false
        )

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val singerId = arguments?.getInt(ARG_SINGER_ID) ?: 0
        val singer = SingerRepository.findById(singerId) ?: return
        val songs = SongRepository.findAllBySingerId(singerId)

        updateMainActivityHeader(singer)
        setupRecyclerView(singer, songs)
    }

    private fun updateMainActivityHeader(singer: SingerModel) {
        val spannable = SpannableStringBuilder("List songs of ${singer.name}")

        spannable.let {
            val start = it.indexOf(singer.name)
            val end = start + singer.name.length

            it.setSpan(
                StyleSpan(Typeface.BOLD),
                start, end, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            it.setSpan(
                ForegroundColorSpan(requireContext().getColor(R.color.dark_red)),
                start, end, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        spannable.let {
            val start = it.indexOf("songs")
            val end = start + "songs".length

            it.setSpan(
                StyleSpan(Typeface.BOLD),
                start, end, SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        (activity as? MainActivity)?.updateHeader(
            title = APP_TITLE,
            description = spannable
        )
    }

    private fun setupRecyclerView(singer: SingerModel, songs: List<SongModel>) {
        binding.rvSongs.layoutManager =
            LinearLayoutManager(requireContext())


//        Log.d(LOG_TAG, "$singerId, ${singer?.name}")
        if (songs.isEmpty()) {
            val spannable = SpannableStringBuilder("Oops, ${singer.name} has no released songs...")

            val start = spannable.indexOf(singer.name)
            val end = start + singer.name.length

            spannable.setSpan(
                StyleSpan(Typeface.BOLD),
                start, end,
                SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            binding.rvSongs.visibility = View.GONE
            binding.tvTotalSongCount.text = spannable
            binding.tvTotalSongCount.gravity = Gravity.CENTER
        } else {
            binding.rvSongs.adapter = SongAdapter(
                singerName = singer.name,
                songs = songs
            )
            binding.tvTotalSongCount.text = "Total songs: ${songs.size}"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }
}