package com.vduczz.ducpv26_assignment5.models

class SongModel(
    var id: Int,
    var name: String,
    var authors: List<SingerModel>,
    var collaborators: List<SingerModel>
)