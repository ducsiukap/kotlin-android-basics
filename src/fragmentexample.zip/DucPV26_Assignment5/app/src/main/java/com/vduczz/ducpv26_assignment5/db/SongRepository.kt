package com.vduczz.ducpv26_assignment5.db

import com.vduczz.ducpv26_assignment5.models.SongModel

object SongRepository {
    fun findById(id: Int): SongModel? = Repository.findById<Song>(id)?.toModel()

    fun findAll(predicate: ((SongModel) -> Boolean)?): List<SongModel> {
        return Repository.findAll<Song>().map { it.toModel() }
            .filter(predicate ?: { true })
    }

    fun findAllBySingerId(singerId: Int): List<SongModel> = findAll {
        it.authors.any { author -> author.id == singerId } ||
        it.collaborators.any { collaborator -> collaborator.id == singerId }
    }

    fun findAll(): List<SongModel> {
        return this.findAll(null)
    }
}

