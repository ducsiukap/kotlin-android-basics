package com.vduczz.ducpv26_assignment5.db

import com.vduczz.ducpv26_assignment5.models.SingerModel
import com.vduczz.ducpv26_assignment5.models.SongModel

fun Singer.toModel(): SingerModel {
    val songCount = Repository.findAll<SongOfSinger> { it.singerId == this.id }
        .distinctBy { it.songId }
        .size
    return SingerModel(id = this.id, name = this.name, songCount = songCount)

}

fun Singer.toModel(songCount: Int): SingerModel {
    return SingerModel(id = this.id, name = this.name, songCount = songCount)
}

fun Song.toModel(): SongModel {
    val authorOrCollaborators = Repository.findAll<SongOfSinger> { it.songId == this.id }
        .distinctBy { it.singerId }

    val singers =
        authorOrCollaborators.map { songOfSinger ->
            Repository.findById<Singer>(songOfSinger.singerId)
        }.filterNotNull()

    val authorOrCollaboratorGroupByRole = authorOrCollaborators.groupBy { it.roleInSong }
    val authorIds = authorOrCollaboratorGroupByRole
        .getOrDefault(RoleInSong.AUTHOR, emptyList())
        .map { it.singerId }
    val collaboratorIds = authorOrCollaboratorGroupByRole
        .getOrDefault(RoleInSong.COLLABORATOR, emptyList())
        .map { it.singerId }

    val authors = singers.filter { it.id in authorIds }.map { it.toModel() }
    val collaborators = singers.filter { it.id in collaboratorIds }.map { it.toModel() }
    return SongModel(
        id = this.id,
        name = this.name,
        authors = authors,
        collaborators = collaborators
    )
}