package com.vduczz.ducpv26_assignment5.db

object Repository {
    inline fun <reified T : Entity> findById(id: Int): T? =
        when (T::class) {
            Singer::class -> Database.singers.firstOrNull { it.id == id }
            SongOfSinger::class -> Database.song_singers.firstOrNull { it.id == id }
            Song::class -> Database.songs.firstOrNull { it.id == id }
            else -> null
        } as? T

    inline fun <reified T : Entity> findAll(): List<T> =
        when (T::class) {
            Singer::class -> Database.singers
            SongOfSinger::class -> Database.song_singers
            Song::class -> Database.songs
            else -> emptyList()
        } as List<T>

    inline fun <reified T : Entity> findAll(predicate: (T) -> Boolean): List<T> =
        when (T::class) {
            Singer::class -> Database.singers.filter { predicate(it as T) }
            SongOfSinger::class -> Database.song_singers.filter { predicate(it as T) }
            Song::class -> Database.songs.filter { predicate(it as T) }
            else -> emptyList()
        } as List<T>
}