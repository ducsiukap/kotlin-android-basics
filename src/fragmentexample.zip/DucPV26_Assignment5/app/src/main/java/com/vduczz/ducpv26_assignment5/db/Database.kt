package com.vduczz.ducpv26_assignment5.db

object Database {

    val singers = listOf(
        Singer(id = 1, name = "Taylor Swift"),
        Singer(id = 2, name = "Ed Sheeran"),
        Singer(id = 3, name = "Justin Bieber"),
        Singer(id = 4, name = "The Weeknd"),
        Singer(id = 5, name = "Ariana Grande"),
        Singer(id = 6, name = "Bruno Mars"),
        Singer(id = 7, name = "Lady Gaga"),
        Singer(id = 8, name = "Beyoncé"),
        Singer(id = 9, name = "Eminem"),
        Singer(id = 10, name = "Adele"),
    )

    val songs = listOf(
        Song(id = 101, name = "Shape of You"),
        Song(id = 102, name = "Perfect"),
        Song(id = 103, name = "Love Yourself"),
        Song(id = 104, name = "Blinding Lights"),
        Song(id = 105, name = "Save Your Tears"),
        Song(id = 106, name = "Die With A Smile"),
        Song(id = 107, name = "Rain On Me"),
        Song(id = 108, name = "Love The Way You Lie"),
        Song(id = 109, name = "Umbrella"),
        Song(id = 110, name = "Crazy In Love"),
        Song(id = 111, name = "I Don't Care"),
        Song(id = 112, name = "Stuck With U")
    )

    val song_singers = listOf(
        SongOfSinger(id = 1, singerId = 2, songId = 101, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 2, singerId = 2, songId = 102, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 3, singerId = 3, songId = 103, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 4, singerId = 4, songId = 104, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 5, singerId = 4, songId = 105, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 6, singerId = 6, songId = 106, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 7, singerId = 7, songId = 106, roleInSong = RoleInSong.COLLABORATOR),
        SongOfSinger(id = 8, singerId = 7, songId = 107, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 9, singerId = 5, songId = 107, roleInSong = RoleInSong.COLLABORATOR),
        SongOfSinger(id = 10, singerId = 9, songId = 108, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 11, singerId = 10, songId = 108, roleInSong = RoleInSong.COLLABORATOR),
        SongOfSinger(id = 12, singerId = 10, songId = 109, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 13, singerId = 8, songId = 110, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 14, singerId = 2, songId = 111, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 15, singerId = 3, songId = 111, roleInSong = RoleInSong.COLLABORATOR),
        SongOfSinger(id = 16, singerId = 5, songId = 112, roleInSong = RoleInSong.AUTHOR),
        SongOfSinger(id = 17, singerId = 3, songId = 112, roleInSong = RoleInSong.COLLABORATOR)
    )
}