package com.vduczz.ducpv26_assignment5.db

sealed class Entity

data class Singer(
    val id: Int,
    val name: String
) : Entity()

class Song(
    val id: Int,
    val name: String,
) : Entity()

class SongOfSinger(
    val id: Int,
    val singerId: Int,
    val songId: Int,
    val roleInSong: RoleInSong
) : Entity()