package com.vduczz.ducpv26_assignment5.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.vduczz.ducpv26_assignment5.databinding.ItemSingerBinding
import com.vduczz.ducpv26_assignment5.models.SingerModel

class SingerAdapter(
    private val singers: List<SingerModel>,
    private val onClickItem: (SingerModel) -> Unit = {}
) : RecyclerView.Adapter<SingerAdapter.SingerViewHolder>() {
    class SingerViewHolder(val binding: ItemSingerBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(singer: SingerModel, onClick: (SingerModel) -> Unit) {
            binding.tvSingerName.text = singer.name
            binding.tvNumberSong.text = "(${singer.songCount})"

            binding.root.setOnClickListener { onClick(singer) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SingerViewHolder {
        val binding = ItemSingerBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return SingerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SingerViewHolder, position: Int) {
        val singer = singers[position]

        holder.bind(singer, onClickItem)
    }

    override fun getItemCount() =
        singers.size

}