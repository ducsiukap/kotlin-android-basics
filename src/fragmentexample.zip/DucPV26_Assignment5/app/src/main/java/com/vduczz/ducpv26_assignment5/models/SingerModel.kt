package com.vduczz.ducpv26_assignment5.models

class SingerModel(
    var id: Int,
    var name: String,
    val songCount: Int = 0
) {
}