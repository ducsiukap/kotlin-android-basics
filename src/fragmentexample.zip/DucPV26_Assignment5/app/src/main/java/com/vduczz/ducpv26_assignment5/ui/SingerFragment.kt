package com.vduczz.ducpv26_assignment5.ui

import android.os.Bundle
import android.text.SpannableStringBuilder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.vduczz.ducpv26_assignment5.R
import com.vduczz.ducpv26_assignment5.adapter.SingerAdapter
import com.vduczz.ducpv26_assignment5.databinding.SingerFragmentBinding
import com.vduczz.ducpv26_assignment5.db.SingerRepository

class SingerFragment : Fragment() {

    companion object {
        private val LOG_TAG = SingerFragment::class.java.simpleName
        private const val APP_TITLE = "List of Singers"
        private const val APP_DESCRIPTION = "Singers"
        fun newInstance() = SingerFragment()
    }

    private var _binding: SingerFragmentBinding? = null
    private val binding: SingerFragmentBinding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = SingerFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.updateHeader(
            title = APP_TITLE,
            description = SpannableStringBuilder(APP_DESCRIPTION)
        )

        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        binding.rvSingers.layoutManager =
            LinearLayoutManager(requireContext())

        binding.rvSingers.adapter =
            SingerAdapter(SingerRepository.findAll()) { singer ->
//                Toast.makeText(
//                    requireContext(),
//                    "Handle click on ${singer.name}",
//                    Toast.LENGTH_SHORT
//                ).show()

                parentFragmentManager.beginTransaction()
                    .replace(
                        R.id.fragmentContainerView,
                        SongOfSingerFragment.newInstance(singer.id)
                    ).addToBackStack(null)
                    .commit()
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}