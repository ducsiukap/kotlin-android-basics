package com.vduczz.ducpv26_assignment5.adapter

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.vduczz.ducpv26_assignment5.databinding.ItemSongBinding
import com.vduczz.ducpv26_assignment5.models.SongModel

class SongAdapter(
    private val singerName: String,
    private val songs: List<SongModel>
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    class SongViewHolder(val binding: ItemSongBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val binding = ItemSongBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return SongViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]

        val authors = buildString {
            append(song.authors.map { it.name }.joinToString(", "))

            val collaborators = song.collaborators.map { it.name }.joinToString(", ")
            if (!collaborators.isNullOrBlank()) {
                append(" ft ")
                append(collaborators)
            }
        }

        val authorsSpannable = SpannableStringBuilder(authors)

        val start = authorsSpannable.indexOf(singerName)
        val end = start + singerName.length

        authorsSpannable.setSpan(
            StyleSpan(Typeface.BOLD),
            start, end,
            SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        authorsSpannable.setSpan(
            UnderlineSpan(),
            start, end,
            SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        holder.binding.tvSongName.text = song.name
        holder.binding.tvAuthors.text = authorsSpannable
    }

    override fun getItemCount() = songs.size
}