package com.vduczz.ducpv26_assignment5.db

enum class RoleInSong {
    AUTHOR, COLLABORATOR
}